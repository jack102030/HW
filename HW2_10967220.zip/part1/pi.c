#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

static double MAGNIFICATION;

typedef struct
{
   int thread_id;
   int start;
   int end;
   double *pi;
} Arg;

pthread_mutex_t mutexsum;   


void *count_pi(void *arg)
{

   Arg *data = (Arg *)arg;
   int thread_id = data->thread_id;
   int start = data->start;
   int end = data->end;
   double *pi = data->pi;

   double x;
   double local_pi = 0;
   double step = 1 / MAGNIFICATION;
   for (int i = start; i < end; i++)
   {
      x = (i + 0.5) * step;
      local_pi += 4 / (1 + x * x);
   }

   local_pi *= step;

   pthread_mutex_lock(&mutexsum);

   *pi += local_pi;
   pthread_mutex_unlock(&mutexsum);

   pthread_exit((void *)0);
}

int main(int argc, char *argv[])
{
	int NUMTHRDS = atoi(argv[1]);
	MAGNIFICATION = atof(argv[2]);
	pthread_t callThd[NUMTHRDS]; 
	
   pthread_mutex_init(&mutexsum, NULL);

   pthread_attr_t attr;
   pthread_attr_init(&attr);
   pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);


   double *pi = (double*)malloc(sizeof(*pi));
   *pi = 0;

   int part = MAGNIFICATION / NUMTHRDS;

   Arg arg[NUMTHRDS]; 
   for (int i = 0; i < NUMTHRDS; i++)
   {
      arg[i].thread_id = i;
      arg[i].start = part * i;
      arg[i].end = part * (i + 1);
      arg[i].pi = pi; 

      pthread_create(&callThd[i], &attr, count_pi, (void *)&arg[i]);
   }

   pthread_attr_destroy(&attr);

   void *status;
   for (int i = 0; i < NUMTHRDS; i++)
   {
      
      pthread_join(callThd[i], &status);
   }

   
   printf("%.10lf \n", *pi);

   
   pthread_mutex_destroy(&mutexsum);
   
   pthread_exit(NULL);
   
   return 0;
}
